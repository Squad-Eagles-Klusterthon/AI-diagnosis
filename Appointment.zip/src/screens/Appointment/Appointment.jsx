import React from "react";
import "./style.css";

export const Appointment = () => {
  return (
    <div className="appointment">
      <div className="div">
        <div className="base">
          <div className="group">
            <div className="nav">
              <div className="dagsb">
                <div className="text-wrapper">Home</div>
              </div>
              <div className="div-wrapper">
                <div className="text-wrapper-2">Appointment</div>
              </div>
              <div className="text-wrapper-3">Chats</div>
              <div className="text-wrapper-3">Documents</div>
            </div>
          </div>
          <div className="text-wrapper-4">Logo</div>
          <div className="icon">
            <div className="notification">
              <div className="overlap-group">
                <img className="vector" alt="Vector" src="/img/vector.svg" />
                <img className="img" alt="Vector" src="/img/vector-1.svg" />
                <div className="ellipse" />
              </div>
            </div>
            <img className="ellipse-2" alt="Ellipse" src="/img/ellipse-3.png" />
          </div>
          <div className="frame">
            <img className="ellipse-3" alt="Ellipse" src="/img/ellipse-4.png" />
            <div className="frame-2">
              <p className="p">Welcome to Your Medpal AI chatbot</p>
              <p className="text-wrapper-5">
                A groundbreaking healthcare software leveraging AI-powered chat agents to transform your experience,
                from streamlined appointment booking to addressing your diverse needs.
              </p>
            </div>
          </div>
          <div className="frame-3" />
          <p className="let-our-AI-help-you">Let Our AI Help You&nbsp;&nbsp;In Addressing Your Needs</p>
        </div>
        <div className="chat-bot">
          <div className="logo">
            <div className="text-wrapper-6">Medpal</div>
            <img className="ellipse-4" alt="Ellipse" src="/img/ellipse-13.png" />
          </div>
          <div className="text">
            <img className="rectangle" alt="Rectangle" src="/img/rectangle-7-2.svg" />
            <p className="text-wrapper-7">HI! How can i help you today ?</p>
          </div>
          <div className="text-2">
            <p className="text-wrapper-8">
              I recommend taking an analgesic, such as paracetamol, and refraining from heavy or fatty foods while
              monitoring the pain. If the pain persists, contact your doctor immediately. Here are some suitable doctors
              available for you to book an appointment:
            </p>
            <div className="frame-4">
              <img className="rectangle-2" alt="Rectangle" src="/img/rectangle-8-1.svg" />
              <div className="icon-park-share-wrapper">
                <img className="icon-park-share" alt="Icon park share" src="/img/icon-park-share.svg" />
              </div>
              <div className="text-wrapper-9">Dr. Ayomide</div>
              <img className="ic-round-star" alt="Ic round star" src="/img/ic-round-star.svg" />
              <img className="ic-round-star-2" alt="Ic round star" src="/img/ic-round-star.svg" />
              <img className="ic-round-star-3" alt="Ic round star" src="/img/ic-round-star.svg" />
              <img className="ic-round-star-4" alt="Ic round star" src="/img/ic-round-star.svg" />
            </div>
            <div className="frame-5">
              <img className="rectangle-2" alt="Rectangle" src="/img/rectangle-8.svg" />
              <div className="icon-park-share-wrapper">
                <img className="icon-park-share" alt="Icon park share" src="/img/icon-park-share.svg" />
              </div>
              <div className="text-wrapper-9">Dr. Ayomide</div>
              <img className="ic-round-star" alt="Ic round star" src="/img/ic-round-star.svg" />
              <img className="ic-round-star-2" alt="Ic round star" src="/img/ic-round-star.svg" />
              <img className="ic-round-star-3" alt="Ic round star" src="/img/ic-round-star.svg" />
              <img className="ic-round-star-4" alt="Ic round star" src="/img/ic-round-star.svg" />
            </div>
          </div>
          <div className="hi-i-am-writing-to-wrapper">
            <p className="hi-i-am-writing-to">
              Hi, I am writing to you with complaints of abdominal pain.
              <br />
              The pain has been occurring over the past few days and has been intensifying.
            </p>
          </div>
          <div className="frame-6">
            <div className="text-wrapper-10">Write a message...</div>
            <div className="overlap">
              <img className="akar-icons-send" alt="Akar icons send" src="/img/akar-icons-send.svg" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
